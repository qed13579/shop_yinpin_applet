declare module '@vue/devtools' {
    export function connect(host?: string, port?: number|string): void
}
